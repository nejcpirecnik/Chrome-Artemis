Hey!
Thank you for downloading my script :)
If you'd like to support me, you can buy me a coffee here: paypal.me/ganks1lent

Instructions:

1. Open Chrome.ps1 and replace YOUR GMAIL HERE with your Gmail address.
2. Upload the Chrome.ps1 to a file sharing service such as MediaFire.
3. Open Script.txt
4. Replace REPLACE THIS WITH .ps1 FILE LINK! with your MediaFire Download link for Chrome.ps1.
5. Save your .txt and encode it for Rubber Ducky.
6. Put the encoded .bin on your Ducky!

If anything doesn't work let me know and I'll fix it asap. MediaFire keeps on blocking my files for being "potentionaly malicious". Can't really blame them lol.